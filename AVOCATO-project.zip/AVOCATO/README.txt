AVOCATO - Starter Android project

Contents:
- Android WebView app using Java + HTML/CSS/JavaScript
- Login with locally created lawyer registry number and password
- Lawyer header details
- Notarization entry, search, draft/approval lock, individual report
- A4 landscape register table with eight columns
- Choose images from device and locally archive them by notarization serial

Build notes:
1. Open this folder in Android Studio or another Android Gradle environment.
2. Use JDK 17 and Android SDK Platform 35; sync Gradle.
3. Build > Build APK(s), then install the APK on your phone.

Important limitations:
- This is a starter prototype, not a tested production legal-record system.
- Login and text records are stored in WebView local storage; image files are stored privately in app storage.
- Uninstalling/clearing app data may erase records. Export/backup, encryption and stronger authentication should be added before real casework.
- Approval locks editing in the app only; it is not a cryptographic signature or official notarization.
- No official website upload is implemented. This requires the exact official portal and an authorized API/integration method.
- Print uses Android's print service. A4 landscape is set by CSS for the list report; check printer settings when printing.
