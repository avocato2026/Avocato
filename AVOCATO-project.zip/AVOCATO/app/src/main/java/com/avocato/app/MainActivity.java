package com.avocato.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.util.Base64;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int PICK_IMAGE = 301;
    private String pendingImageCallback = "";
    private File dataDir, imageDir, dbFile;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dataDir = new File(getFilesDir(), "avocato"); dataDir.mkdirs();
        imageDir = new File(dataDir, "images"); imageDir.mkdirs();
        dbFile = new File(dataDir, "archive.json");
        webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new Bridge(), "Avocato");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private JSONArray readArray() {
        try { if (!dbFile.exists()) return new JSONArray(); byte[] b = readAll(new FileInputStream(dbFile)); return new JSONArray(new String(b, "UTF-8")); }
        catch (Exception e) { return new JSONArray(); }
    }
    private void writeArray(JSONArray a) {
        try (FileOutputStream out = new FileOutputStream(dbFile)) { out.write(a.toString().getBytes("UTF-8")); }
        catch (Exception ignored) {}
    }
    private byte[] readAll(InputStream in) throws IOException { ByteArrayOutputStream b = new ByteArrayOutputStream(); byte[] buf = new byte[8192]; int n; while((n=in.read(buf))>0)b.write(buf,0,n); in.close(); return b.toByteArray(); }
    private void js(String code) { runOnUiThread(() -> webView.evaluateJavascript(code, null)); }
    private String q(String s) { return JSONObject.quote(s == null ? "" : s); }

    public class Bridge {
        @JavascriptInterface public String getDocuments() {
            JSONArray a = readArray(); JSONArray out = new JSONArray();
            for (int i=0;i<a.length();i++) { JSONObject item=a.optJSONObject(i); if(item==null)continue;
                try { JSONObject x = new JSONObject(item.toString()); File f = new File(imageDir, x.optString("file")); if(f.exists()) x.put("dataUrl", "data:image/*;base64,"+Base64.encodeToString(readAll(new FileInputStream(f)), Base64.NO_WRAP)); out.put(x); } catch(Exception ignored){}
            } return out.toString();
        }
        @JavascriptInterface public void chooseImage(String callbackName) {
            pendingImageCallback = callbackName;
            runOnUiThread(() -> { Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT); i.addCategory(Intent.CATEGORY_OPENABLE); i.setType("image/*"); startActivityForResult(i, PICK_IMAGE); });
        }
        @JavascriptInterface public void saveDocument(String json) {
            try {
                JSONObject incoming = new JSONObject(json); String id = incoming.optString("id", UUID.randomUUID().toString());
                String data = incoming.optString("dataUrl", ""); int comma = data.indexOf(','); if(comma<0)return;
                byte[] bytes = Base64.decode(data.substring(comma+1), Base64.DEFAULT);
                String fileName = id.replaceAll("[^A-Za-z0-9_-]", "") + ".img";
                try(FileOutputStream out=new FileOutputStream(new File(imageDir,fileName))){out.write(bytes);}
                JSONObject item = new JSONObject(); item.put("id",id); item.put("serial",incoming.optString("serial")); item.put("type",incoming.optString("type")); item.put("file",fileName); item.put("name",incoming.optString("name")); item.put("created",incoming.optString("created"));
                JSONArray old=readArray(), next=new JSONArray(); for(int i=0;i<old.length();i++){JSONObject x=old.optJSONObject(i); if(x!=null&&!x.optString("id").equals(id))next.put(x);} next.put(item); writeArray(next); js("if(window.onNativeSaved) window.onNativeSaved(true)");
            } catch(Exception e){js("if(window.onNativeSaved) window.onNativeSaved(false)");}
        }
        @JavascriptInterface public void deleteDocument(String id) {
            JSONArray old=readArray(), next=new JSONArray(); for(int i=0;i<old.length();i++){JSONObject x=old.optJSONObject(i); if(x==null)continue; if(x.optString("id").equals(id)){new File(imageDir,x.optString("file")).delete();} else next.put(x);} writeArray(next);
        }
        @JavascriptInterface public void printPage() { runOnUiThread(() -> { PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE); PrintDocumentAdapter adapter=webView.createPrintDocumentAdapter("AVOCATO"); pm.print("AVOCATO",adapter,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build()); }); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_IMAGE && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri uri=data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored){}
            try {
                byte[] bytes=readAll(getContentResolver().openInputStream(uri)); String mime=getContentResolver().getType(uri); if(mime==null)mime="image/jpeg";
                String name="image"; Cursor c=getContentResolver().query(uri,null,null,null,null); if(c!=null){if(c.moveToFirst()){int idx=c.getColumnIndex(OpenableColumns.DISPLAY_NAME);if(idx>=0)name=c.getString(idx);}c.close();}
                js("if(window.onNativeImageSelected) window.onNativeImageSelected("+q("data:"+mime+";base64,"+Base64.encodeToString(bytes,Base64.NO_WRAP))+","+q(name)+")");
            } catch(Exception e){ js("alert('تعذر فتح الصورة المختارة')"); }
        }
    }
}
